//
//  StringConstants.swift
//  GreenWorld
//
//  Created by ChaimaEljed on 1/12/2023.
//

import Foundation
struct StringConstants {

    static let Logo: String = "Green World"
   
    static let profil: String = "Profil"
    static let email: String = "GreenWorldUserøtn.tn"
    static let wlc: String = " Welcomme Green wORLD"
    static let plz: String = "Please enter your dat to connect"
    static let quiz: String = "Quiz"
    static let achat: String = "my purchases"
}
