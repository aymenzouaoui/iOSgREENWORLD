//
//  Event.swift
//  GreenWorld
//
//  Created by ChaimaEljed on 30/11/2023.
//

import Foundation
